import streamlit as st
import pickle
import numpy as np
import os

# Set page configuration
st.set_page_config(
    page_title="LBV Prediction App",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load the KNN model at startup
@st.cache_resource
def load_model():
    """Load the pre-trained KNN model from pickle file"""
    # Try multiple possible model file names
    possible_paths = [
        "knn_model.pkl",
        "knn_models (2)_1749133064980.pkl",
        "model.pkl",
        "knn_models.pkl"
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            try:
                with open(path, "rb") as file:
                    model = pickle.load(file)
                st.success(f"✅ Model loaded successfully from {path}")
                return model
            except Exception as e:
                st.error(f"❌ Error loading model from {path}: {str(e)}")
                continue
    
    # If no model found, show error
    st.error("❌ Model file not found. Please ensure one of the following files exists in the project directory:")
    for path in possible_paths:
        st.write(f"- {path}")
    st.stop()

# Initialize the model
try:
    model = load_model()
except Exception as e:
    st.error(f"❌ Failed to initialize model: {str(e)}")
    st.stop()

# Main application
def main():
    # Title and description
    st.title("🔥 Laminar Burning Velocity (LBV) Prediction")
    st.markdown("""
    This application predicts the Laminar Burning Velocity using a pre-trained K-Nearest Neighbors (KNN) model.
    Enter the required parameters below to get your prediction.
    """)
    
    # Create two columns for better layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("📊 Input Parameters")
        
        # Create input form
        with st.form("prediction_form"):
            # Hydrocarbon dropdown
            hydrocarbon_options = {
                "DME - air mixture": 1,
                "Methane - air mixture": 2,
                "Propane - air mixture": 3,
                "Butane - air mixture": 4,
                "Ethanol - air mixture": 5,
                "Hydrogen - air mixture": 6,
                "Ethane - air mixture": 7,
                "Acetylene - air mixture": 8,
                "Benzene - air mixture": 9,
                "Toluene - air mixture": 10,
                "n-Heptane - air mixture": 11,
                "iso-Octane - air mixture": 12,
                "Gasoline - air mixture": 13,
                "Diesel - air mixture": 14,
                "Kerosene - air mixture": 15,
                "Natural Gas - air mixture": 16,
                "LPG - air mixture": 17,
                "Methanol - air mixture": 18,
                "n-Butanol - air mixture": 19,
                "Cyclohexane - air mixture": 20,
                "n-Pentane - air mixture": 21,
                "n-Hexane - air mixture": 22,
                "Ethylene - air mixture": 23,
                "Propylene - air mixture": 24,
                "1-Butene - air mixture": 25,
                "1-Pentene - air mixture": 26,
                "1-Hexene - air mixture": 27,
                "Cyclopentane - air mixture": 28,
                "Methylcyclohexane - air mixture": 29,
                "Decane - air mixture": 30,
                "Dodecane - air mixture": 31,
                "JP-8 - air mixture": 32,
                "JP-10 - air mixture": 33,
                "RP-1 - air mixture": 34,
                "Syngas - air mixture": 35,
                "Biogas - air mixture": 36,
                "Ammonia - air mixture": 37,
                "Carbon Monoxide - air mixture": 38
            }
            
            selected_hydrocarbon = st.selectbox(
                "Hydrocarbon",
                options=list(hydrocarbon_options.keys()),
                index=0
            )
            hydrocarbon = hydrocarbon_options[selected_hydrocarbon]
            
            # Temperature input
            temperature = st.number_input(
                "Initial Temperature (K)",
                min_value=300.0,
                max_value=634.8,
                value=450.0,
                step=1.0
            )
            st.caption("Valid range: 300.0 - 634.8 K")
            
            # Phi (equivalence ratio) input
            phi = st.number_input(
                "Equivalence Ratio (φ)",
                min_value=0.69,
                max_value=1.64,
                value=0.7,
                step=0.01
            )
            st.caption("Valid range: 0.69 - 1.64")
            
            # Pressure input
            pressure = st.number_input(
                "Pressure (atm)",
                min_value=1.00,
                max_value=1.00,
                value=1.0,
                step=0.01
            )
            st.caption("Valid range: 1.00 - 1.00 atm")
            
            # Submit button
            submitted = st.form_submit_button("🔍 Predict LBV", use_container_width=True)
        
        # Input validation and prediction
        if submitted:
            # Validate inputs
            if hydrocarbon <= 0:
                st.error("❌ Error: Hydrocarbon value must be greater than 0")
            elif temperature <= 0:
                st.error("❌ Error: Temperature must be greater than 0 K")
            elif phi <= 0:
                st.error("❌ Error: Phi (equivalence ratio) must be greater than 0")
            elif pressure <= 0:
                st.error("❌ Error: Pressure must be greater than 0 atm")
            else:
                # Make prediction
                try:
                    # Prepare input data as numpy array
                    input_data = np.array([[hydrocarbon, temperature, phi, pressure]])
                    
                    # Make prediction
                    with st.spinner("🔄 Making prediction..."):
                        prediction = model.predict(input_data)
                        
                    # Display results in the second column
                    with col2:
                        st.header("🎯 Prediction Results")
                        
                        # Display prediction with formatting
                        st.metric(
                            label="Laminar Burning Velocity",
                            value=f"{prediction[0]:.4f} m/s",
                            help="Predicted LBV in meters per second"
                        )
                        
                        # Display input summary
                        st.subheader("📋 Input Parameters")
                        st.write(f"**Hydrocarbon:** {selected_hydrocarbon}")
                        st.write(f"**Temperature:** {temperature} K")
                        st.write(f"**Equivalence Ratio:** {phi}")
                        st.write(f"**Pressure:** {pressure} atm")
                        
                        # Success message
                        st.success("✅ Prediction completed successfully!")
                        
                except Exception as e:
                    st.error(f"❌ Error during prediction: {str(e)}")
                    st.write("Please check your input values and try again.")
    
    with col2:
        if not submitted:
            st.header("🎯 Prediction Results")
            st.info("Enter parameters and click 'Predict LBV' to see results here")

# Sidebar with additional information
def create_sidebar():
    st.sidebar.header("📚 About the Model")
    st.sidebar.markdown("""
    **Model Type:** K-Nearest Neighbors (KNN)
    
    **Purpose:** Predicts Laminar Burning Velocity based on combustion parameters
    
    **Input Features:**
    - Hydrocarbon concentration
    - Temperature (K)
    - Equivalence ratio (Phi)
    - Pressure (atm)
    
    **Output:** Laminar Burning Velocity (m/s)
    """)
    
    st.sidebar.header("🔧 Model Information")
    if model:
        try:
            # Try to get model parameters if available
            if hasattr(model, 'n_neighbors'):
                st.sidebar.write(f"**Neighbors (k):** {model.n_neighbors}")
            if hasattr(model, 'metric'):
                st.sidebar.write(f"**Distance Metric:** {model.metric}")
            if hasattr(model, 'n_features_in_'):
                st.sidebar.write(f"**Input Features:** {model.n_features_in_}")
        except:
            st.sidebar.write("Model details not available")
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("**📞 Need Help?**")
    st.sidebar.markdown("Ensure all input values are within the specified ranges for accurate predictions.")

# Run the application
if __name__ == "__main__":
    # Create sidebar
    create_sidebar()
    
    # Run main application
    main()
    
    # Footer
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "LBV Prediction App | Powered by Streamlit & KNN Model"
        "</div>", 
        unsafe_allow_html=True
    )
